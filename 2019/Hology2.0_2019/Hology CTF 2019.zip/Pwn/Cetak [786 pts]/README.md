Description:
Lengkap, tapi mantap!</br>
</br>
</br>
</br>
nc 34.87.0.60 2056

Hint:
