Description:
nc 34.87.0.60:2058

Hint:
