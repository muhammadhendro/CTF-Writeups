Description:
Berikut contoh string yang perlu dicari
</br>
hctf{F1nd_s0methin_lik3_thI5_0k}

Hint:
