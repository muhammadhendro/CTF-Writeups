Description:
Anak Intern perusahaan kami percaya, jika program cukup sulit untuk ditulis, berarti program tersebut juga harus cukup sulit untuk dibaca. 
</br>
Jika program cukup sulit untuk dibaca, berarti cukup sulit untuk dimanipulasi.

Hint:
