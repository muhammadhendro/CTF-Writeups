Description:
I've Learnt PHP. I'd love it if you wanna try my web. Connect to 34.87.0.60:2051 and tell me if something wrong!

Hint:
