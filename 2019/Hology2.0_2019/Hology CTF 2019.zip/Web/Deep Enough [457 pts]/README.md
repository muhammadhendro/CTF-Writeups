Description:
I believe that my secret string is deep enough
</br>
34.87.0.60:2052

Hint:
