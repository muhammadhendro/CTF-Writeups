Description:
I think my friend hide flag.php somewhere, but I cant reach it. Would you mind to help me?
</br>
34.87.0.60:2050

Hint:
