Description:
Disaat sensei ari sudah berkata tugas kriptografi. 9 dari 10 Mahasiswa akan mengerjakan tugas mata kuliah lain.

Hint:
