Description:
Bahkan アリ先生 bisa mengerjakannya dengan mata tertutup
</br>
Care, its ENCrypted with Really Secure Algorithm

Hint:
