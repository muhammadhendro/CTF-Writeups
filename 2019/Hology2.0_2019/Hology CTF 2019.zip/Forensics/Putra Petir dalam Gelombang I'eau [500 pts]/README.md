Description:
Negeri I'eau sangat terkenal dengan gelombang-gelombang pasang laut yang menakutkan. konon katanya, gelombang itu dapat merusak apa saja yang menghampirinya.
</br>
Anton mengirimkan suatu hal yang begitu rahasia menuju negeri tersebut. Namun, hal tersebut rusak dibuatnya. Bisakah kamu melihat hal rahasia tersebut?

Hint:
