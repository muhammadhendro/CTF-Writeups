Description:
Jika fotografer bisa membuat beberapa foto tajam dari satu foto dan menjualnya secara personal. Ia akan melakukannya. Terkadang profit lebih penting dari value secara utuh. Bagaimana menurutmu?

Hint:
